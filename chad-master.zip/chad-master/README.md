# chad
## chad
This shows the importance of computer science to jobs in the future. Within the next ten years, upwards of 323,000 job applications will be put in for software developers alone. Over 700,000 job applications DIRECTLY related to computer science will be submitted. That being said, there will be even more jobs where a basic understanding of of computer science will be beneficiary.

[Source](https://appliedcomputing.wisconsin.edu/about-applied-computing/computer-science-jobs/)
